import os
from typing import List
from pydantic import BaseModel, Field


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _env_list(name: str, default: List[str]) -> List[str]:
    value = os.getenv(name)
    if not value:
        return default
    return [item.strip() for item in value.split(",") if item.strip()]


class Settings(BaseModel):
    # App
    PROJECT_NAME: str = "ParseAnything Backend API"
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    # Server. Keep both naming conventions for deployment compatibility.
    HOST: str = os.getenv("API_HOST", os.getenv("HOST", "0.0.0.0"))
    PORT: int = _env_int("API_PORT", _env_int("FASTAPI_PORT", 8001))

    # Redis & Celery
    # Docker uses the service name "redis"; local development can override these.
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    CELERY_BROKER_URL: str = os.getenv(
        "CELERY_BROKER_URL",
        os.getenv("REDIS_URL", "redis://localhost:6379/0"),
    )
    CELERY_RESULT_BACKEND: str = os.getenv(
        "CELERY_RESULT_BACKEND",
        os.getenv("REDIS_URL", "redis://localhost:6379/1"),
    )

    # Storage
    UPLOAD_DIR: str = os.getenv("UPLOAD_DIR", os.path.abspath("uploads"))
    RESULTS_DIR: str = os.getenv("RESULTS_DIR", os.path.abspath("results"))
    SAMPLES_DIR: str = os.getenv("SAMPLES_DIR", os.path.abspath("backend/samples"))

    # File limits. MAX_FILE_SIZE_MB is the public deployment variable.
    MAX_FILE_SIZE_MB: int = _env_int(
        "MAX_FILE_SIZE_MB",
        max(1, _env_int("MAX_FILE_SIZE_BYTES", 25 * 1024 * 1024) // (1024 * 1024)),
    )
    MAX_FILE_SIZE_BYTES: int = Field(default=25 * 1024 * 1024, exclude=True)
    CONFIDENCE_THRESHOLD: float = _env_float("CONFIDENCE_THRESHOLD", 0.70)

    # Upload types
    ALLOWED_EXTENSIONS: set[str] = {"pdf", "jpg", "jpeg", "png", "docx"}

    # CORS: comma-separated URLs. Empty means same-origin only.
    CORS_ORIGINS: List[str] = Field(
        default_factory=lambda: _env_list(
            "CORS_ORIGINS",
            [
                "http://localhost:3000",
                "http://127.0.0.1:3000",
                "http://localhost:8080",
                "http://127.0.0.1:8080",
            ],
        )
    )

    class Config:
        arbitrary_types_allowed = True


settings = Settings()
settings.MAX_FILE_SIZE_BYTES = max(1, settings.MAX_FILE_SIZE_MB) * 1024 * 1024
